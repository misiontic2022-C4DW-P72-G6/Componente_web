module.exports = {

     auth_api_url: 'https://userc4dw-db.herokuapp.com',
      //auth_api_url: 'http://127.0.0.1:8000', 
     reservas_api_url:'https://reservasdw-be.herokuapp.com',
     // auth_api_url: 'http://127.0.0.1:8000',
     habitacion_api_url: 'https://microservicio-catalogo.herokuapp.com/',
     //catalogo_api_url:'http://127.0.0.1:8000',
     catalogo_api_url:'https://microservicio-catalogo.herokuapp.com/',

     
 };
 