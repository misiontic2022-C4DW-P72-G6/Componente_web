const catalogoResolver = {
    Query: {
        catalogoDetailById: (_, {catalogoId}, { dataSources}) => {
            console.log("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz")
            console.log(catalogoId)
            let result = dataSources.catalogoAPI.getCatalogo(catalogoId)
            console.log(result)
            return result
    
        },
    },
};
module.exports = catalogoResolver;