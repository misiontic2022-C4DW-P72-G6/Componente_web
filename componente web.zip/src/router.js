import { createRouter, createWebHistory } from "vue-router";
import App from './App.vue';
import LogIn from './components/LogIn.vue'
import SignUp from './components/SignUp.vue'
import Home from './components/Home.vue'
import Account from './components/Account.vue'
import catalogo from './components/catalogo.vue'
import habitacion from './components/habitacion.vue'
import reservas from './components/reservas.vue'
const routes = [{
    path: '/',
    name: 'root',
    component: App
},
{
    path: '/user/logIn',
    name: "logIn",
    component: LogIn
},
{
    path: '/user/signUp',
    name: "signUp",
    component: SignUp
},
{
    path: '/user/home',
    name: "home",
    component: Home
},

{
    path: '/user/reservas',
    name: "reservas",
    component: reservas
},

{
    path: '/user/catalogo',
    name: "catalogo",
    component: catalogo
},
{
    path: '/user/habitacion',
    name: 'root',
    component: habitacion
},


];
const router = createRouter({
    history: createWebHistory(),
    routes,
});
export default router;