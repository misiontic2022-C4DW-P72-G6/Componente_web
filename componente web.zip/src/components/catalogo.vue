<template>
  <div class="information1">
      
    <div class="create-route1">
      <h1>Nuestros Hoteles Asociados</h1>
    </div>

  
      <div class="cuadro_contenedor">

        <div class="create-route">
          Hotel Guajira:<br>
         <div v-for="catalogoId in catalogoDetailById" >{{ catalogoId}} </div>
        </div>
        <br />

      
        <div class="create-route">
          Hotel Santa Marta:<br>
         <div v-for="catalogoId in catalogoDetailById" >{{ catalogoId}} </div>
        </div>
        <br />

                <div class="create-route">
         Hotel Bogotá:<br>
         <div v-for="catalogoId in catalogoDetailById" >{{ catalogoId}} </div>
        </div>




      </div>
        
      
        
  </div>
  

</template>

<script>
import gql from "graphql-tag";

export default {
  name: "catalogo",
  data () {

    return {
     catalogoId:1,


     /* catalogoId: jwt_decode(localStorage.getItem("token_refresh")).catalogo_id, */
     /* catalogoId: localStorage.getItem("catalogoId") ,*/
     
      catalogoDetailById: {
        Nombre: "",
        Ubicacion: "",
        Calificacion: "",
        Direccion: "",
        Descripcion: "",
        Correo: "",    


      }

    };
  },


  apollo: {
    catalogoDetailById: {
      query: gql`
        query Query($catalogoId: Int!) {
          catalogoDetailById(catalogoId: $catalogoId) {
            Nombre
            Ubicacion
            Calificacion
            Direccion
            Descripcion
            Correo
          }
        }
      `,
      variables() {
        return {
          catalogoId: this.catalogoId,
        };
      },
    },
  },
};

</script>

<style>
.cuadro_contenedor {
  padding: 10px;
  margin-bottom: 10px;
  background-color: rgb(245, 245, 245);
  border: solid 1px red;
  display: grid;
  grid-template-columns: 33% 33% 33%;
  border-radius: 10px;
  box-shadow: 3px 3px 3px 2px rgba(197, 23, 23, 0.2);
  width: 50%;
  height: auto;
  text-align: right;
}
.create-route {
  border-radius: 5px;
  text-align: right;
  margin: 1px;
  padding: 0px;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.information1 {
  margin: 0;
  padding: 0%;
  width: 90%;
  height: 90%;
  display: flex;
  flex-direction: left;
  justify-content: center;
  align-items: center;
}
.information1 h1 {
  font-size: 60px;
  color: #283747;
}
.information1 h2 {
  font-size: 40px;
  color: #283747;
}
.information1 span {
  color: crimson;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
.details h3 {
  font-size: 35px;
  color: #283747;
  text-align: center;
}
.details h2 {
  font-size: 35px;
  color: #283747;
}
.details {
  border: 3px solid #283747;
  border-radius: 10px;
  width: 80%;
  height: 80%;
  display: flex;
  flex-direction: column;
  justify-content: right;
  align-items: right;
}
</style>